package org.assignment.utils;

import org.assignment.model.ShopModel;

import java.util.Formatter;

/**
 * Statistics class is being used to capture the stats,
 * which will be used to print them on the statistics.txt f
 * ile.
 */
public class Statistics {

    /**
     * Method responsible for creating the statistics details
     *
     * @param shopModel ShopModel object which contains the required details
     *                  for the statistics
     *
     * @param formatter Formatter object for formatting the contents into
     *                  the required format
     */
    public void  createStatisticsFromModel(ShopModel shopModel, Formatter formatter) {
        String output = "\nStatistics\n" +
                "==========\n";
        formatter.format(output);

        String peopleServed = "The number of people served = %s\n";
        formatter.format(peopleServed, shopModel.getNumServed());

        String lostBusiness = "The lost business  = %s people\n";
        formatter.format(lostBusiness, shopModel.getLostBusiness());
    }
}
