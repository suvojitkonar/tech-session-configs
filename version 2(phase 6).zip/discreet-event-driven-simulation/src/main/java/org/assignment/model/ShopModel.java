package org.assignment.model;

import java.util.*;

/**
 * Class ShopModel contains the details for the shop.
 * It has information regarding the groups, history,
 * id etc.
 *
 * Takes number of seats as the constructor parameter.
 */
public class ShopModel {

    private List<CustomerGroup> groups = new ArrayList<>();

    private List<CustomerGroup> history = new ArrayList<>();

    private int nextId;

    private int numGroups;

    private static int nextIdentifier = 0;

    public static int numOfGroupsInShop = 0;

    private int numberOfSeats;

    private int lostBusiness = 0;

    private int numServed = 0;

    //Constructor
    public ShopModel(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    /**
     * Adds customer group to the group list
     * @param customerGroup CustomerGroup object
     */
    public void addGroup(CustomerGroup customerGroup) {
        this.groups.add(customerGroup);
        numOfGroupsInShop += 1;
    }

    /**
     * Logs groups to the logs list
     * @param customerGroup CustomerGroup object
     */
    public void logGroup(CustomerGroup customerGroup) {
        this.history.add(customerGroup);
    }

    /**
     * Shows the information about the groups stored in the
     * group list.
     * @param formatter java.util.Formatter object for
     *                  writing to a file.
     *
     * @return List of CustomerGroup
     */
    public List<CustomerGroup> showGroups(Formatter formatter) {
        String output = "\nThe following groups are in the shop:\n" +
                "=====================================\n";
        formatter.format(output);
        this.groups.forEach(data -> {
            String values = "Group    %s (%s people) arrived at t = %s\n";
            formatter.format(values,data.getId(), data.getNumberInGroup(), data.getArrivalTime());
        });
        return this.groups;
    }

    /**
     * Shows the information about the logs stored in the
     * log list.
     * @param formatter java.util.Formatter object for
     *                  writing to a file.
     *
     * @return List of CustomerGroup
     */
    public List<CustomerGroup> showLog(Formatter formatter) {
        String output = "\nThe following groups are in the history/log:\n" +
                "============================================\n";
        formatter.format(output);
        this.history.forEach(data -> {
            String values = "Group    %s (%s people) arrived at t = %s\n";
            formatter.format(values,data.getId(), data.getNumberInGroup(), data.getArrivalTime());
        });
        return this.history;
    }

    /**
     * fetches the next unique identifier
     * @return Integer
     */
    public int getNextId(){
        nextId = nextIdentifier;
        nextIdentifier = nextIdentifier + 1;
        return nextId;
    }

    public int getNumberOfSeats(){
        return this.numberOfSeats;
    }

    public void setNumberOfSeats(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    public int getLostBusiness() {
        return lostBusiness;
    }

    public void setLostBusiness(int lostBusiness) {
        this.lostBusiness = lostBusiness;
    }

    public int getNumServed() {
        return numServed;
    }

    public void setNumServed(int numServed) {
        this.numServed = numServed;
    }

    /**
     * Prints information about the orders served
     * @param time Integer
     * @param g CustomerGroup
     */
    public void serveOrder(int time, CustomerGroup g){
        System.out.println("t= " + time +  ":" +  " Order served for Group " + g.getId());
    }

    /**
     * Used when the customer groups are leaving the shop
     * @param time Integer
     * @param g CustomerGroup
     */
    public void leave(int time,  CustomerGroup g){
        groups.remove(g);
        numGroups -= 1;
        System.out.println("t= " + time + ": Group " + g.getId() + " leaves");
    }

    /**
     * Checks if customer groups are allowed to sit in the shop.
     * Returns true if allowed, else false
     * @param time Integer
     * @param group CustomerGroup
     * @return boolean
     */
    public boolean canSeat(int time, CustomerGroup group){
        int groupSize = group.getNumberInGroup();
        int capacity = this.getNumberOfSeats();
        if( groupSize <= capacity) {
            this.setNumberOfSeats(capacity - groupSize);
            //calculating number of customers served
            this.setNumServed(this.getNumServed() + groupSize);
            System.out.println("t= " + time + ": Group "
                    + group.getId() + " ( " + groupSize + " people " + " ) " + "seated");
            return true;
        }
        //calculating number of customers lost or the business lost
        this.setLostBusiness(this.getLostBusiness() + groupSize);
        System.out.println("t= " + time + ": Group "
                + group.getId() + " leaves as there are insufficient seats for the group");
        return false;
    }
}
