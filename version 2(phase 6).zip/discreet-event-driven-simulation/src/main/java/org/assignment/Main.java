package org.assignment;
import org.assignment.events.ArrivalEvent;
import org.assignment.events.Event;
import org.assignment.model.CustomerGroup;
import org.assignment.model.ShopModel;
import org.assignment.simulator.Simulator;
import org.assignment.utils.FileWriter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * Main class for driving the program.
 * This is also entry point for the
 * code.
 */
public class Main {
    public static void main(String[] args) {
            ShopModel shopModel = new ShopModel(5);
            Simulator simulator = new Simulator(shopModel);
            ArrayList<Event> events = new ArrayList<>();
            events.add(new ArrivalEvent(0));
            simulator.initialize(events);
            simulator.run(30);
            //Writing the statistics to a text file
            FileWriter fileWriter = new FileWriter();
            fileWriter.writeToAFile(shopModel);
    }
}