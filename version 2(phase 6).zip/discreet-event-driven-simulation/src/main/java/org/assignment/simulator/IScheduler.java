package org.assignment.simulator;

import org.assignment.events.Event;

public interface IScheduler {
    public void schedule( Event e );
}
