package org.assignment.simulator;

import org.assignment.model.ShopModel;
import org.assignment.events.Event;

import java.util.ArrayList;

/**
 * This class is responsible for running the simulation trace
 */
public class Simulator implements IScheduler {
    private ArrayList<Event> events;
    private int clock;
    private ShopModel model;

    //Constructor
    public Simulator(ShopModel model) {
        this.model = model;
    }

    /**
     * Initialize method is used to initialize the
     * event queue
     * @param eventQueue ArrayList of events
     */
    public void initialize(ArrayList<Event> eventQueue){
        this.events = eventQueue;
    }

    /**
     * Used to run the simulation
     * @param stopTime Stop time or the time for which the simulation
     *                 will execute
     */
    public void run(int stopTime) {
        if ((events == null)|| events.isEmpty() )
            return;
        Event e = events.remove(0);
        clock = e.getTime();
        while (clock <= stopTime) {
            e.process(model, this);
            e = events.remove(0);
            clock = e.getTime();
        }
    }

    /**
     * This method schedules the simulation.
     * @param event Event object which needs to be scheduled
     */
    @Override
    public void schedule(Event event) {
        events.add(event);
    }
}
