package org.assignment.events;

import org.assignment.simulator.IScheduler;
import org.assignment.model.ShopModel;

import java.util.Random;

/**
 * Abstract event class. Stores the information
 * about the events triggered.
 *
 * This is being inherited by the child classes
 * like - ArrivalEvent, OrderEvent and LeaveEvent
 */
public abstract class Event {

    private int time;

    // random generator with a seed value of 1
    static Random generator = new Random(1);

    public Event(int time) {
        this.time = time;
    }

    public int getTime() {
        return time;
    }

    public Random getGenerator(){
        return generator;
    }

    /**
     * needs to be implemented by the child classes
     */
    public abstract void process(ShopModel sm, IScheduler s );
}
