package org.assignment.events;

import org.assignment.model.CustomerGroup;
import org.assignment.model.ShopModel;
import org.assignment.simulator.IScheduler;

import java.util.Collections;
import java.util.Comparator;

/**
 * Class responsible for handling the leave events.
 * This extends the abstract event class.
 */
public class ArrivalEvent extends Event {

    private int groupLowerBound = 1;
    private int groupGeneratorBound = 4;

    private int orderTimeAfterArrivalLowerBound = 1;
    private int orderTimeAfterArrivalBound = 5;

    public ArrivalEvent(int time) {
        super(time);
    }

    /**
     * Implementation of the super class process method. Used
     * to process the order events.
     * @param sm ShopModel object
     * @param s IScheduler reference
     */
    @Override
    public void process(ShopModel sm, IScheduler s) {
        int groupSize = super.getGenerator().nextInt(groupGeneratorBound) + groupLowerBound;
        int orderTimeAfterArrival = super.getGenerator().nextInt(orderTimeAfterArrivalBound) + orderTimeAfterArrivalLowerBound;
        int nextId = sm.getNextId();
        CustomerGroup customerGroup = new CustomerGroup(nextId, groupSize, this.getTime());
        sm.logGroup(customerGroup);
        int capacity = sm.getNumberOfSeats();
        System.out.println("t=  " + getTime() + " group: " + nextId + " < " + groupSize + " people arrived >" );
        s.schedule(new ArrivalEvent(super.getTime() + 2));
        if (sm.canSeat(this.getTime(), customerGroup)) {
            sm.addGroup(customerGroup);
            s.schedule(new OrderEvent(this.getTime() + orderTimeAfterArrival, customerGroup));
        }
    }
}
