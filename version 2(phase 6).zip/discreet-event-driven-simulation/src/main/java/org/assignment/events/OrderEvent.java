package org.assignment.events;

import org.assignment.model.CustomerGroup;
import org.assignment.simulator.IScheduler;
import org.assignment.model.ShopModel;

/**
 * Class responsible for handling the order events.
 * This extends the abstract event class.
 */
public class OrderEvent extends Event {
   private CustomerGroup customerGroup;
    private int leaveEventLowerBound = 5;
    private int leaveEventBound = 12;

    //Constructor
    public OrderEvent(int time, CustomerGroup customerGroup) {
        super(time);
        this.customerGroup = customerGroup;
    }

    /**
     * Implementation of the super class process method. Used
     * to process the order events.
     * @param sm ShopModel object
     * @param s IScheduler reference
     */
    @Override
    public void process(ShopModel sm, IScheduler s) {
        int leaveTime = super.getGenerator().nextInt(leaveEventBound) + leaveEventLowerBound;

        //serves the order
        sm.serveOrder(this.getTime(), this.customerGroup);
        s.schedule(new LeaveEvent(this.getTime() + leaveTime, customerGroup));
    }
}
