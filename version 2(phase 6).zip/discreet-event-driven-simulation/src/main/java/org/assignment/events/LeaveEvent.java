package org.assignment.events;

import org.assignment.model.CustomerGroup;
import org.assignment.simulator.IScheduler;
import org.assignment.model.ShopModel;

/**
 * Class responsible for handling the leave events.
 * This extends the abstract event class.
 */
public class LeaveEvent extends Event {

    private CustomerGroup customerGroup;

    public LeaveEvent(int time, CustomerGroup customerGroup) {
        super(time);
        this.customerGroup = customerGroup;
    }

    /**
     * Implementation of the super class process method. Used
     * to process the order events.
     * @param sm ShopModel object
     * @param s IScheduler reference
     */
    @Override
    public void process(ShopModel sm, IScheduler s) {
        sm.leave(this.getTime(), customerGroup);
        sm.setNumberOfSeats(sm.getNumberOfSeats() + customerGroup.getNumberInGroup());
    }
}
