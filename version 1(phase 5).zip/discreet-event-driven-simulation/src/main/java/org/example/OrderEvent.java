package org.example;

public class OrderEvent extends Event{
   private CustomerGroup customerGroup;

    public OrderEvent(int time, CustomerGroup customerGroup) {
        super(time);
        this.customerGroup = customerGroup;
    }

    @Override
    public void process(ShopModel sm, IScheduler s) {
        sm.serveOrder(this.getTime(), this.customerGroup);
        s.schedule(new LeaveEvent(this.getTime() + 10, customerGroup));

    }
}
