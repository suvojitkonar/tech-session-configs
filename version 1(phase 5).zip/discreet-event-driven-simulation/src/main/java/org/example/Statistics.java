package org.example;

import java.util.Formatter;

public class Statistics {

    public void  createStatisticsFromModel(ShopModel shopModel, Formatter formatter) {
        String output = "\nStatistics\n" +
                "==========\n";
        formatter.format(output);

        String peopleServed = "The number of people served = %s\n";
        formatter.format(peopleServed, shopModel.getNumServed());

        String lostBusiness = "The lost business  = %s people\n";
        formatter.format(lostBusiness, shopModel.getLostBusiness());
    }
}
