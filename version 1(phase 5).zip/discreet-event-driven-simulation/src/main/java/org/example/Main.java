package org.example;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
            ShopModel shopModel = new ShopModel();
            Simulator simulator = new Simulator(shopModel);
            ArrayList<Event> events = new ArrayList<>();
            events.add(new ArrivalEvent(0));
            simulator.initialize(events);
            simulator.run(20);

            //Writing the statistics to a text file
            FileWriter fileWriter = new FileWriter();
            fileWriter.writeToAFile(shopModel);
    }
}