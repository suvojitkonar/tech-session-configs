package org.example;

public class CustomerGroup {

    private int id;

    private int numberInGroup;

    private int arrivalTime;

    public CustomerGroup(int id, int numberInGroup, int arrivalTime) {
        this.id = id;
        this.numberInGroup = numberInGroup;
        this.arrivalTime = arrivalTime;
    }

    public int getId() {
        return this.id;
    }

    public int getNumberInGroup() {
        return this.numberInGroup;
    }

    public int getArrivalTime() {
        return this.arrivalTime;
    }

    @Override
    public String toString() {
        return "CustomerGroup{" +
                "id=" + id +
                ", numberInGroup=" + numberInGroup +
                ", arrivalTime=" + arrivalTime +
                '}';
    }
}
