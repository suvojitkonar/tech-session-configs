package org.example;

public abstract class Event {

    private int time;

    public Event(int time) {
        this.time = time;
    }

    public int getTime() {
        return time;
    }

    public abstract void process(ShopModel sm, IScheduler s );
}
