package org.example;
import java.util.*;

public class ShopModel {

    private List<CustomerGroup> groups = new ArrayList<>();

    private List<CustomerGroup> history = new ArrayList<>();

    private int nextId;

    private int numGroups;

    private static int nextIdentifier = 0;

    public static int numOfGroupsInShop = 0;

    private int numberOfSeats = 8;

    private int lostBusiness = 0;

    private int numServed = 0;

    public ShopModel() {
    }

    public ShopModel(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    public void addGroup(CustomerGroup customerGroup) {
        this.groups.add(customerGroup);
        numOfGroupsInShop += 1;
    }

    public void logGroup(CustomerGroup customerGroup) {
        this.history.add(customerGroup);
    }

    public List<CustomerGroup> showGroups(Formatter formatter) {
        String output = "\nThe following groups are in the shop:\n" +
                "=====================================\n";
        formatter.format(output);
        this.groups.forEach(data -> {
            String values = "Group    %s (%s people) arrived at t = %s\n";
            formatter.format(values,data.getId(), data.getNumberInGroup(), data.getArrivalTime());
        });
        return this.groups;
    }

    public List<CustomerGroup> showLog(Formatter formatter) {
        String output = "\nThe following groups are in the history/log:\n" +
                "============================================\n";
        formatter.format(output);
        this.history.forEach(data -> {
            String values = "Group    %s (%s people) arrived at t = %s\n";
            formatter.format(values,data.getId(), data.getNumberInGroup(), data.getArrivalTime());
        });
        return this.history;
    }

    public int getNextId(){
        nextId = nextIdentifier;
        nextIdentifier = nextIdentifier + 1;
        return nextId;
    }

    public int getNumberOfSeats(){
        return this.numberOfSeats;
    }

    public void setNumberOfSeats(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    public int getLostBusiness() {
        return lostBusiness;
    }

    public void setLostBusiness(int lostBusiness) {
        this.lostBusiness = lostBusiness;
    }

    public int getNumServed() {
        return numServed;
    }

    public void setNumServed(int numServed) {
        this.numServed = numServed;
    }

    public void serveOrder(int time, CustomerGroup g){
        System.out.println("t= " + time +  ":" +  " Order served for Group " + g.getId());
    }

    public void leave(int time,  CustomerGroup g){
        groups.remove(g);
        numGroups -= 1;
        System.out.println("t= " + time + ": Group " + g.getId() + " leaves");
    }
}
