package org.example;

public class LeaveEvent extends Event{

    private CustomerGroup customerGroup;

    public LeaveEvent(int time, CustomerGroup customerGroup) {
        super(time);
        this.customerGroup = customerGroup;
    }

    @Override
    public void process(ShopModel sm, IScheduler s) {
        sm.leave(this.getTime(), customerGroup);
        sm.setNumberOfSeats(sm.getNumberOfSeats() + customerGroup.getNumberInGroup());
    }
}
