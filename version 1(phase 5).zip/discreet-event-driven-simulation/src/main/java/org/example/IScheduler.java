package org.example;

public interface IScheduler {
    public void schedule( Event e );
}
