package org.example;

public class ArrivalEvent extends Event {
    protected ArrivalEvent(int time) {
        super(time);
    }

    @Override
    public void process(ShopModel sm, IScheduler s) {
        int groupSize = 2;
        int nextId = sm.getNextId();
        CustomerGroup customerGroup = new CustomerGroup(nextId, groupSize, this.getTime());
        sm.logGroup(customerGroup);
        int capacity = sm.getNumberOfSeats();
        System.out.println("t=  " + this.getTime() + " group: " + nextId + " < " + groupSize + " people arrived >" );
        s.schedule(new ArrivalEvent(super.getTime() + 2));
        if (canGroupBeSeated(groupSize, capacity, nextId, sm)) {
            sm.addGroup(customerGroup);
            s.schedule(new OrderEvent(this.getTime() + 1, customerGroup));
        }
    }

    private boolean canGroupBeSeated(int groupSize, int capacity, int groupId, ShopModel sm){
        if( groupSize < capacity) {
            sm.setNumberOfSeats(capacity - groupSize);
            //calculating number of customers served
            sm.setNumServed(sm.getNumServed() + groupSize);
            System.out.println("t= " + this.getTime()+ ": Group "
                    + groupId + " ( " + groupSize + " people " + " ) " + "seated");
            return true;
        }
        //calculating number of customers lost or the business lost
        sm.setLostBusiness(sm.getLostBusiness() + groupSize);
        System.out.println("t= " + this.getTime()+ ": Group "
                + groupId + " leaves as there are insufficient seats for the group");
        return false;
    }
}
