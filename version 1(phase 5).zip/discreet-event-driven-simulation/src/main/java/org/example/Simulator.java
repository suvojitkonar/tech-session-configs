package org.example;

import java.util.ArrayList;

public class Simulator implements IScheduler {
    private ArrayList<Event> events;
    private int clock;
    private ShopModel model;

    public Simulator(ShopModel model) {
        this.model = model;
    }

    public void initialize(ArrayList<Event> eventQueue){
        this.events = eventQueue;
    }

    public void run(int stopTime) {
        if ((events == null)|| events.isEmpty() )
            return;
        Event e = events.remove(0);
        clock = e.getTime();
        while (clock <= stopTime) {
            e.process(model, this);
            e = events.remove(0);
            clock = e.getTime();
        }
    }

    @Override
    public void schedule(Event e) {
        events.add(e);
    }
}
