package org.example;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Formatter;

public class FileWriter {

    public void writeToAFile(ShopModel shopModel) {
        try {
            File file = new File("statistics.txt");
            PrintWriter writer = new PrintWriter(file);
            Formatter formatter = new Formatter(writer);

            Statistics statistics = new Statistics();
            statistics.createStatisticsFromModel(shopModel, formatter);
            shopModel.showGroups(formatter);
            shopModel.showLog(formatter);

            formatter.close();
            writer.close();

        } catch (FileNotFoundException fileNotFoundException) {
            System.out.println("Some exception while writing to the file");
        }
    }
}
